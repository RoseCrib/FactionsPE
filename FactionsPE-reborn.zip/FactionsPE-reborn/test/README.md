### What are those?!?
These files will be executed if plugin is enabled in developer mode. Only files with suffix ```_test.php``` will be executed in context of FactionsPE(PluginBase)
