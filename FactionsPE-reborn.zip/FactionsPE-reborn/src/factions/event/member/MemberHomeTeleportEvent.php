<?php
/*
 *   FactionsPE: PocketMine-MP Plugin
 *   Copyright (C) 2016  Chris Prime
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace factions\event\member;

use factions\entity\IMember;
use pocketmine\event\Cancellable;
use pocketmine\level\Position;

class MemberHomeTeleportEvent extends MemberEvent implements Cancellable
{

    public static $handlerList = null;
    public static $eventPool = [];
    public static $nextEvent = 0;

    /** @var Position */
    public $home;

    public function __construct(IMember $member, Position $home)
    {
        parent::__construct($member);
        $this->home = $home;
    }

    public function getDestination()
    {
        return $this->home;
    }

    public function setDestination(Position $home)
    {
        $this->home = $home;
    }

    public function getMember()
    {
        return $this->member;
    }

}