<?php
/*
 *   FactionsPE: PocketMine-MP Plugin
 *   Copyright (C) 2016  Chris Prime
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace factions\command;

use dominate\Command;
use factions\command\parameter\FactionParameter;
use factions\entity\Faction;
use factions\manager\Members;
use factions\manager\Permissions;
use factions\utils\Gameplay;
use factions\relation\Relation as REL;
use factions\utils\Text;
use localizer\Localizer;
use pocketmine\command\CommandSender;
use pocketmine\utils\TextFormat;
use factions\engine\ChatEngine;

class Info extends Command
{

    public function setup()
    {
        // Parameters
        $this->addParameter((new FactionParameter("faction"))->setDefaultValue("self"));
    }

    public function perform(CommandSender $sender, $label, array $args)
    {
	    // Args
        /** @var Faction $faction */
        $faction = $this->getArgument(0);
        $member = Members::get($sender);

        // Collect data
        $id = $faction->getId();
        $description = $faction->getDescription();
        $age = $faction->getAge();
        $flags = $faction->getFlags();
        $power = [
            "Land" => $faction->getLandCount(),
            "Power" => $faction->getPower(), 
            "Maxpower" => $faction->getPowerMax()
            ];
        $f = "";
        foreach ($flags as $flag => $value) {
            $f .= ($value ? "<green>" : "<red>")."$flag <yellow>| ";
        }
        $flags = rtrim($f, "| ");

        $relations = [
            REL::ALLY => $faction->getFactionsWhereRelation(REL::ALLY),
            REL::TRUCE => $faction->getFactionsWhereRelation(REL::TRUCE),
            REL::ENEMY => $faction->getFactionsWhereRelation(REL::ENEMY)
        ];
        $title = Text::titleize("Faction ".$member->getColorTo($faction).$faction->getName());

        // Format and send
        $member->sendMessage($title);
        $member->sendMessage(Text::parse("<gold>ID: <yellow>".$id));
        $member->sendMessage(Text::parse("<gold>Description: <yellow>".$description));
        $member->sendMessage(Text::parse("<gold>Age: <purple>".Text::time_elapsed($age)));
        $member->sendMessage(Text::parse("<gold>Flags: ".$flags));
        $member->sendMessage(Text::parse("<gold>".implode(TextFormat::YELLOW." / ", array_keys($power)).": <yellow>".implode(TextFormat::YELLOW."/", array_values($power))));
        foreach ($relations as $rel => $factions) {
            $member->sendMessage(Text::parse("<gold>Relation ".REL::getColor($rel).ucfirst($rel)." <gold>(".count($factions)."):"));
            if(empty($factions)) {
                $member->sendMessage(Text::parse("<gray>none"));
            } else {
                $member->sendMessage(Text::parse(implode(" ", array_map(function($f){return $f->getName();}, $factions))));
            }
        }
        $member->sendMessage(Text::parse("<yellow>Followers Online (" . count($faction->getOnlineMembers()) . "):"));
        $members = [];
        foreach($faction->getOnlineMembers() as $m) {
            $members[] = "<green>".ChatEngine::getBadge($m->getRole())."<rose>".$faction->getName()." <green>".$m->getDisplayName();
        }
        if(empty($members)) {
            $members[] = "<gray>none";
        }
        $member->sendMessage(Text::parse(rtrim(implode(', ', $members), ', ')));
        $member->sendMessage(Text::parse("<yellow>Followers Offline (" . count($faction->getOfflineMembers()) . "):"));
        $members = [];
        foreach($faction->getOfflineMembers() as $m) {
            $members[] = "<green>".ChatEngine::getBadge($m->getRole())."<rose>".$faction->getName()." <green>".$m->getDisplayName();
        }
        // Text::getRelationColor(Relation::getRelationOfThatToMe($m, $member)) # Should I add this instead of showing
        # All factions red?
        if(empty($members)) {
            $members[] = "<gray>none";
        }
        $member->sendMessage(Text::parse(rtrim(implode(', ', $members), ', ')));


        return true;
    }

}
