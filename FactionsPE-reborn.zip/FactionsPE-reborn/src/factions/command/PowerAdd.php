<?php
/**
 * Created by PhpStorm.
 * User: chris
 * Date: 17.27.3
 * Time: 21:53
 */

namespace factions\command;


use dominate\Command;

class PowerAdd extends Command
{

    public function setup() {

    }

}